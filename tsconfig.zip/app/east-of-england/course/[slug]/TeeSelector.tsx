"use client";

import { useRouter } from "next/navigation";

type Tee = {
  id: string;
  name: string;
};

type TeeSelectorProps = {
  tees: Tee[];
  selectedTeeId: string;
};

export default function TeeSelector({
  tees,
  selectedTeeId,
}: TeeSelectorProps) {
  const router = useRouter();

  return (
    <div className="mt-6">
      <label className="mb-2 block font-semibold text-[#173b2c]">
        Choose tee
      </label>

      <select
        value={selectedTeeId}
        onChange={(event) => router.push(`?tee=${event.target.value}`)}
        className="w-full rounded-lg border border-gray-300 bg-white px-4 py-3"
      >
        {tees.map((tee) => (
          <option key={tee.id} value={tee.id}>
            {tee.name}
          </option>
        ))}
      </select>
    </div>
  );
}